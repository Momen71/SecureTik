from flask import Flask, jsonify, request
from flask import render_template
import subprocess
import json
import threading
import time

app = Flask(__name__)

CLIENT_DATA_FILE = "/tmp/client_data.json"
SCRIPT_PATH = "/home/ubuntu/traffic_control/tc_script.sh"  # Update with your actual path


def read_clients():
    try:
        with open(CLIENT_DATA_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}

@app.route("/clients", methods=["GET"])
def clients():
    data = read_clients()
    return jsonify(list(data.keys()))


@app.route("/usage/<client_ip>", methods=["GET"])
def usage(client_ip):
    data = read_clients()
    client = data.get(client_ip)
    if not client:
        return jsonify({"error": "Client not found"}), 404
    return jsonify({
        "usage_mb": client.get("usage_mb", 0),
        "quota_limit_mb": client.get("quota_limit_mb", 0),
        "quota_exceeded": client.get("quota_exceeded", False)
    })


@app.route("/set_quota", methods=["POST"])
def set_quota():
    # Expects JSON: {"client_ip": "...", "rate": "10mbit", "ceil": "15mbit", "quota_mb": 100}
    content = request.json
    client_ip = content.get("client_ip")
    rate = content.get("rate")
    ceil = content.get("ceil")
    quota_mb = content.get("quota_mb", 100)

    if not all([client_ip, rate, ceil]):
        return jsonify({"error": "Missing fields"}), 400

    # Call your bash script add_client function
    try:
        subprocess.check_output([
            "sudo", SCRIPT_PATH, "add_client", client_ip, rate, ceil, str(quota_mb)
        ])
    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"Failed to set quota: {e.output.decode()}"}), 500

    return jsonify({"status": "success"})


@app.route("/reset_quota", methods=["POST"])
def reset_quota():
    content = request.json
    client_ip = content.get("client_ip")
    if not client_ip:
        return jsonify({"error": "Missing client_ip"}), 400

    try:
        subprocess.check_output([
            "sudo", SCRIPT_PATH, "reset_quota", client_ip
        ])
    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"Failed to reset quota: {e.output.decode()}"}), 500

    return jsonify({"status": "success"})

@app.route("/")
def index():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
