#!/bin/bash

IFACE_INTERNET="ens33"
IFACE_LAN="ens34"
TC=/sbin/tc

LOG_FILE="/var/log/tc_usage.log"
CLIENT_DATA="/tmp/client_data.json"

create_tc_rules() {
    echo "Creating TC rules..."
    clean_tc_rules
    tc qdisc add dev $IFACE_INTERNET root handle 1: htb default 999
    tc class add dev $IFACE_INTERNET parent 1: classid 1:1 htb rate 1000mbit ceil 1000mbit
    tc qdisc add dev $IFACE_LAN root handle 1: htb default 999
    tc class add dev $IFACE_LAN parent 1: classid 1:1 htb rate 1000mbit ceil 1000mbit
    tc class add dev $IFACE_INTERNET parent 1:1 classid 1:999 htb rate 20mbit ceil 30mbit
    tc qdisc add dev $IFACE_INTERNET parent 1:999 sfq perturb 10
    tc class add dev $IFACE_LAN parent 1:1 classid 1:999 htb rate 20mbit ceil 30mbit
    tc qdisc add dev $IFACE_LAN parent 1:999 sfq perturb 10
    echo "Default rules applied: rate 20mbit, ceil 30mbit for all clients."
}

clean_tc_rules() {
    echo "Cleaning existing TC rules..."
    tc qdisc del dev $IFACE_INTERNET root 2>/dev/null
    tc qdisc del dev $IFACE_LAN root 2>/dev/null
    echo "TC rules cleaned."
}

add_or_update_client_rules() {
    local CLIENT_IP=$1
    local RATE=$2
    local CEIL=$3
    local QUOTA_MB=${4:-100}

    local LAST_OCTET=$(echo $CLIENT_IP | awk -F. '{print $4}')
    local DL_CLASSID=$LAST_OCTET
    local UL_CLASSID=$((LAST_OCTET + 1))

    echo "➕ Adding/Updating rules for client $CLIENT_IP"
    echo "   📦 Download Class: 1:$DL_CLASSID on $IFACE_LAN"
    echo "   📤 Upload Class:   1:$UL_CLASSID on $IFACE_INTERNET"
    echo "   🚦 Rate: $RATE | Ceil: $CEIL | Quota: ${QUOTA_MB}MB"

    tc class del dev $IFACE_INTERNET parent 1:1 classid 1:$UL_CLASSID 2>/dev/null
    tc class del dev $IFACE_LAN parent 1:1 classid 1:$DL_CLASSID 2>/dev/null

    tc class add dev $IFACE_INTERNET parent 1:1 classid 1:$UL_CLASSID htb rate $RATE ceil $CEIL
    tc qdisc add dev $IFACE_INTERNET parent 1:$UL_CLASSID sfq perturb 10
    tc filter add dev $IFACE_INTERNET protocol ip prio 1 u32 match ip src $CLIENT_IP flowid 1:$UL_CLASSID

    tc class add dev $IFACE_LAN parent 1:1 classid 1:$DL_CLASSID htb rate $RATE ceil $CEIL
    tc qdisc add dev $IFACE_LAN parent 1:$DL_CLASSID sfq perturb 10
    tc filter add dev $IFACE_LAN protocol ip prio 1 u32 match ip dst $CLIENT_IP flowid 1:$DL_CLASSID

    if [[ ! -f "$CLIENT_DATA" ]]; then
        echo "{}" > "$CLIENT_DATA"
    fi

    jq --arg ip "$CLIENT_IP" \
       --arg dl_id "1:$DL_CLASSID" \
       --arg ul_id "1:$UL_CLASSID" \
       --arg rate "$RATE" \
       --arg ceil "$CEIL" \
       --argjson quota "$QUOTA_MB" \
       --argjson usage 0 \
       --argjson exceeded false \
       '.[$ip] = {
           download_id: $dl_id,
           upload_id: $ul_id,
           rate: $rate,
           ceil: $ceil,
           quota_limit_mb: $quota,
           usage_mb: $usage,
           quota_exceeded: $exceeded
        }' "$CLIENT_DATA" > tmp.json && mv tmp.json "$CLIENT_DATA"

    echo "✅ Client $CLIENT_IP fully added with traffic shaping and tracking"
}

reset_client_quota() {
    local CLIENT_IP=$1
    echo "🔄 Resetting quota for client $CLIENT_IP..."

    local DL_CLASSID=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].download_id' "$CLIENT_DATA")
    local UL_CLASSID=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].upload_id' "$CLIENT_DATA")
    local RATE=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].rate' "$CLIENT_DATA")
    local CEIL=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].ceil' "$CLIENT_DATA")

    if [[ "$DL_CLASSID" == "null" || "$UL_CLASSID" == "null" || -z "$RATE" || -z "$CEIL" ]]; then
        echo "❌ Missing data for $CLIENT_IP. Cannot reset."
        return 1
    fi

    echo "🔁 Recreating classes to reset usage counters..."

    # Delete filters first (LAN)
    tc filter del dev $IFACE_LAN protocol ip parent 1: prio 1 u32 match ip dst $CLIENT_IP flowid $DL_CLASSID 2>/dev/null
    # Then delete qdisc and class (LAN)
    tc qdisc del dev $IFACE_LAN parent $DL_CLASSID 2>/dev/null
    tc class del dev $IFACE_LAN classid $DL_CLASSID 2>/dev/null

    # Delete filters first (Internet)
    tc filter del dev $IFACE_INTERNET protocol ip parent 1: prio 1 u32 match ip src $CLIENT_IP flowid $UL_CLASSID 2>/dev/null
    # Then delete qdisc and class (Internet)
    tc qdisc del dev $IFACE_INTERNET parent $UL_CLASSID 2>/dev/null
    tc class del dev $IFACE_INTERNET classid $UL_CLASSID 2>/dev/null

    sleep 0.1

    echo "Before adding DL rules:"
    tc class show dev $IFACE_LAN
    tc filter show dev $IFACE_LAN

    echo "Before adding UL rules:"
    tc class show dev $IFACE_INTERNET
    tc filter show dev $IFACE_INTERNET

    # Add class, qdisc, filter fresh (LAN)
    tc class add dev $IFACE_LAN parent 1:1 classid $DL_CLASSID htb rate $RATE ceil $CEIL
    tc qdisc add dev $IFACE_LAN parent $DL_CLASSID handle ${DL_CLASSID#1:}0: sfq perturb 10
    tc filter add dev $IFACE_LAN protocol ip prio 1 u32 match ip dst $CLIENT_IP flowid $DL_CLASSID

    # Add class, qdisc, filter fresh (Internet)
    tc class add dev $IFACE_INTERNET parent 1:1 classid $UL_CLASSID htb rate $RATE ceil $CEIL
    tc qdisc add dev $IFACE_INTERNET parent $UL_CLASSID handle ${UL_CLASSID#1:}0: sfq perturb 10
    tc filter add dev $IFACE_INTERNET protocol ip prio 1 u32 match ip src $CLIENT_IP flowid $UL_CLASSID

    # Reset usage tracking in JSON
    jq --arg ip "$CLIENT_IP" '.[$ip].usage_mb = 0 | .[$ip].quota_exceeded = false' "$CLIENT_DATA" > tmp.json && mv tmp.json "$CLIENT_DATA"

    echo "✅ Quota + speed reset for $CLIENT_IP"
}


monitor_and_enforce_quota() {
    echo "📱 Monitoring usage and enforcing quota..."

    for CLIENT_IP in $(jq -r 'keys[]' "$CLIENT_DATA"); do
        DL_CLASSID=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].download_id' "$CLIENT_DATA")
        UL_CLASSID=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].upload_id' "$CLIENT_DATA")
        RATE=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].rate' "$CLIENT_DATA")
        CEIL=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].ceil' "$CLIENT_DATA")
        QUOTA_MB=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].quota_limit_mb' "$CLIENT_DATA")
        QUOTA_EXCEEDED=$(jq -r --arg ip "$CLIENT_IP" '.[$ip].quota_exceeded' "$CLIENT_DATA")

        DL_BYTES=$(tc -s class show dev $IFACE_LAN | awk "/class htb $DL_CLASSID/{found=1} found && /Sent/ {print \$2; exit}")
        UL_BYTES=$(tc -s class show dev $IFACE_INTERNET | awk "/class htb $UL_CLASSID/{found=1} found && /Sent/ {print \$2; exit}")
        DL_BYTES=${DL_BYTES:-0}
        UL_BYTES=${UL_BYTES:-0}
        TOTAL_BYTES=$((DL_BYTES + UL_BYTES))
        USAGE_MB=$((TOTAL_BYTES / 1024 / 1024))

        jq --arg ip "$CLIENT_IP" --argjson used "$USAGE_MB" '.[$ip].usage_mb = $used' "$CLIENT_DATA" > tmp.json && mv tmp.json "$CLIENT_DATA"

        if (( USAGE_MB == 0 )); then
            echo "🟢 [$CLIENT_IP] Usage 0% of quota"
        fi

        PERCENT=$((USAGE_MB * 100 / QUOTA_MB))

        if (( PERCENT >= 100 )); then
            echo "🚫 [$CLIENT_IP] Quota exceeded! ($USAGE_MB / $QUOTA_MB MB)"
            if [[ "$QUOTA_EXCEEDED" != "true" ]]; then
                tc class change dev $IFACE_LAN classid $DL_CLASSID htb rate 1kbit ceil 100kbit
                tc class change dev $IFACE_INTERNET classid $UL_CLASSID htb rate 1kbit ceil 100kbit
                jq --arg ip "$CLIENT_IP" '.[$ip].quota_exceeded = true' "$CLIENT_DATA" > tmp.json && mv tmp.json "$CLIENT_DATA"
                echo "✅ Throttled $CLIENT_IP"
            fi
        elif (( PERCENT >= 75 )); then
            echo "🔴 [$CLIENT_IP] Usage 75% of quota"
        elif (( PERCENT >= 50 )); then
            echo "🟠 [$CLIENT_IP] Usage 50% of quota"
        elif (( PERCENT >= 25 )); then
            echo "🔹 [$CLIENT_IP] Usage 25% of quota"
        else
            echo "✅ [$CLIENT_IP] Usage $USAGE_MB / $QUOTA_MB MB ($PERCENT%)"
        fi
    done
}

monitor_loop() {
    echo "🔁 Starting background quota monitor every 5s..."
    while true; do
        monitor_and_enforce_quota
        sleep 5
    done
}

case "$1" in
    "create") create_tc_rules ;;
    "clean") clean_tc_rules ;;
    "add_client") add_or_update_client_rules $2 $3 $4 $5 ;;
    "reset_quota") reset_client_quota $2 ;;
    "monitor") monitor_and_enforce_quota ;;
    "monitor_loop") monitor_loop ;;
    *)
        echo "Usage: $0 {create|clean|add_client <ip> <rate> <ceil> [quota_mb]|reset_quota <ip>|monitor|monitor_loop}"
        exit 1
        ;;
esac
