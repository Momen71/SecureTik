Usage: ./tc_script.sh {create|clean|add_client <ip> <rate> <ceil> [quota_mb]|reset_quota <ip>|monitor|monitor_loop}


For Dashboad UI : 
1- set speed and quota 
2- reset
